/*Name: Chadrick Liang
Class: DIT/FT/1B/07
Admin No.: P2227634*/
export function populate_specific_result(title, rental_rate) {
    var tmpToken = localStorage.getItem('token');
    var data = `{"title": "${title}",
                "rental_rate": "${rental_rate}"}`;
    //console.log(`This is the request body ${data}`);
    return $.ajax({
        headers: { 'authorization': 'Bearer ' + tmpToken },
        url: `http://localhost:8081/film_categories/films/search`,
        type: 'POST',
        data: data,
        contentType: "application/json",
        dataType: 'json',
        success: function (data) {
            var resultData = [];
            //console.log(`Success: ${typeof JSON.stringify(data)}`);
            data.forEach(function (x) {
                resultData.push(x);
            });
            var loc_arr = ['images/p1.png', 'images/p2.png', 'images/p3.png', 'images/p4.png', 'images/p5.png', 'images/p6.png', 'images/p7.png', 'images/p8.png', 'images/p9.png', 'images/p10.png'];
            var loc_index = 0;
            for (let i = 0; i < resultData.length; i++) {
                if (loc_index < 10) {
                    $('#container').append(`<div class="movie" style="display: grid"><p class="movie-name">${resultData[i].title}<br>
                    ${resultData[i].release_year}<br>
                    ${resultData[i].rating}</p><img class="thumbnail" src="${loc_arr[loc_index]}"
                alt=""></div>`);
                    loc_index++;
                } else {
                    loc_index = 0;
                    $('#container').append(`<div class="movie" style="display: grid"><p class="movie-name">${resultData[i].title}<br>
                    ${resultData[i].release_year}<br>
                    ${resultData[i].rating}</p><img class="thumbnail" src="${loc_arr[loc_index]}"
                alt=""></div>`);
                }
                //console.log('pushed');
            }
        },
        error: function (xhr, textStatus, errorThrown) {
            console.log('Error in Operation');
        }
    });
};
