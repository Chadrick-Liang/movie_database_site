/*Name: Chadrick Liang
Class: DIT/FT/1B/07
Admin No.: P2227634*/
export function get_details() {
    var tmpToken = localStorage.getItem('token');
    var search_title = sessionStorage.getItem('movie_to_search');
    //sessionStorage.removeItem('movie_to_search');
    var data = `{"title": "${search_title}"}`;
    return $.ajax({
        headers: { 'authorization': 'Bearer ' + tmpToken },
        url: `http://localhost:8081/film_categories/film`,
        type: 'POST',
        data: data,
        contentType: "application/json",
        dataType: 'json',
        success: function (result) {
            //console.log(`Success: ${JSON.stringify(result)}`);
            //console.log(result[0]["description"]);
            var actor_string = '';
            for (let i = 0; i < result[0]["actors"].length; i++) {
                actor_string += `${result[0]["actors"][i]["first_name"]} ${result[0]["actors"][i]["last_name"]}, `;
            }
            actor_string = actor_string.slice(0, -2);
            //console.log(actor_string);
            $('.movie-title').text(search_title);
            $('#category').text(`Genre: ${result[0]["name"]}`);
            $('#year').text(`Year: ${result[0]["release_year"]}`);
            $('#description').text(result[0]["description"]);
            $('#rating').text(`Content rating: ${result[0]["rating"]}`);
            $('#actors').text(`Actors: ${actor_string}`);
        },
        error: function (xhr, textStatus, errorThrown) {
            console.log('Error in Operation');
        }
    });
};
