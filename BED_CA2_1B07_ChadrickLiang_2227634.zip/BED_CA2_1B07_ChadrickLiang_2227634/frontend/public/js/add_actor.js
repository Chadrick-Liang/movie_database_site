/*Name: Chadrick Liang
Class: DIT/FT/1B/07
Admin No.: P2227634*/
export function add_actor() {
    var tmpToken = localStorage.getItem('token');
    var first_name = $('#first_name').val();
    var last_name = $('#last_name').val();

    var data = `{"first_name": "${first_name}",
                 "last_name": "${last_name}"}`;
    console.log(`THIS IS THE REQUEST BODY ${data}`);
    return $.ajax({
        headers: { 'authorization': 'Bearer ' + tmpToken },
        url: `http://localhost:8081/actors`,
        type: 'POST',
        data: data,
        contentType: "application/json",
        dataType: 'json',
        success: function (result) {
            console.log(result);
            console.log('Created successfully');
            window.alert("New actor has been successfully added.");
        },
        error: function (xhr, textStatus, errorThrown) {
            console.log('Error in Operation');
            window.alert("Something went wrong with your submission.");
        }
    });
};