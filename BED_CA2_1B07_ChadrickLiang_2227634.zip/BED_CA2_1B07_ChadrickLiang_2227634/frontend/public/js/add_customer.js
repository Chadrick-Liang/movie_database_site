/*Name: Chadrick Liang
Class: DIT/FT/1B/07
Admin No.: P2227634*/
export function add_customer() {
    var tmpToken = localStorage.getItem('token');
    var store_id = $('#store_id').val();
    var first_name = $('#first_name').val();
    var last_name = $('#last_name').val();
    var email = $('#email').val();
    var address1 = $('#address1').val();
    var address2 = $('#address2').val();
    var district = $('#district').val();
    var city_id = $('#city_id').val();
    var postal_code = $('#postal_code').val();
    var phone = $('#phone').val();

    var data = `{"store_id": "${store_id}",
                 "first_name": "${first_name}",
                 "last_name": "${last_name}",
                 "email": "${email}",
                 "address1": "${address1}",
                 "address2": "${address2}",
                 "district": "${district}",
                 "city_id": "${city_id}",
                 "postal_code": "${postal_code}",
                 "phone": "${phone}"}`;
    console.log(`THIS IS THE REQUEST BODY ${data}`);
    return $.ajax({
        headers: { 'authorization': 'Bearer ' + tmpToken },
        url: `http://localhost:8081/customers`,
        type: 'POST',
        data: data,
        contentType: "application/json",
        dataType: 'json',
        success: function (result) {
            console.log(result);
            console.log('Created successfully');
            window.alert("New customer has been successfully added.");
        },
        error: function (xhr, textStatus, errorThrown) {
            console.log('Error in Operation');
            window.alert("Something went wrong with your submission.");
        }
    });
};
