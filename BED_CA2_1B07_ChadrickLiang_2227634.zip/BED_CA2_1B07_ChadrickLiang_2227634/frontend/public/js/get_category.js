/*Name: Chadrick Liang
Class: DIT/FT/1B/07
Admin No.: P2227634*/
export function get_category() {
    var tmpToken = localStorage.getItem('token');
    return $.ajax({
        headers: { 'authorization': 'Bearer ' + tmpToken },
        url: `http://localhost:8081/film_categories`,
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            var initialData = [];
            //console.log(`Success: ${JSON.stringify(data)}`);
            data.forEach(function (x) {
                initialData.push(x);
            });
            //console.log(initialData[5]['name']);
            for (let i = 0; i < initialData.length; i++) {
                $('#category').append(`<option value="${initialData[i]['category_id']}">${initialData[i]['name']}</option>`);
                //console.log('pushed');
            }
        },
        error: function (xhr, textStatus, errorThrown) {
            console.log('Error in Operation');
        }
    });
};
