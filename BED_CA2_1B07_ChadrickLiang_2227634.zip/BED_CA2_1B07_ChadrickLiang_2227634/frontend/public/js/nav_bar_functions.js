/*Name: Chadrick Liang
Class: DIT/FT/1B/07
Admin No.: P2227634*/
export function logout() {
    console.log('I am leaving');
    window.localStorage.clear();
    window.location.assign("http://localhost:3001/login.html");
}

export function toHome() {
    console.log('I am going home');
    window.location.assign("http://localhost:3001/home.html");
}