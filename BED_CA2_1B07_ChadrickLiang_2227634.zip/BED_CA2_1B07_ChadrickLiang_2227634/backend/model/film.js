/*Name: Chadrick Liang
Class: DIT/FT/1B/07
Admin No.: P2227634*/
var db = require('./databaseConfig.js');
var config = require('../config.js');
var jwt = require('jsonwebtoken');

var filmDB = {
    getFilmsData: function (category_id, callback) {
        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                console.log(`Connected!`);
                //create an sql query that joins and selects information about the film from the tables film, fim_category and category
                var sqlQuery = `SELECT film.film_id, film.title, category.name, film.rating, film.release_year, film.length
                FROM film
                INNER JOIN film_category ON film.film_id=film_category.film_id
                INNER JOIN category ON film_category.category_id=category.category_id
                WHERE category.category_id = ?`;
                conn.query(sqlQuery, [category_id], function (err, result) {
                    conn.end();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        console.log(result);
                        //the result is now an array of objects with key value pairs that are different from the ones desired.
                        //iterate on each object of the array
                        result.forEach(movie => {
                            //add new key value pairs with the desired naming convention and data type before deleting the old ones.
                            movie['category'] = movie['name'];
                            delete movie['name'];
                            movie['duration'] = String(movie['length']);
                            delete movie['length'];
                            //create a model object template
                            const template = {
                                'film_id': null,
                                'title': null,
                                'category': null,
                                'rating': null,
                                'release_year': null,
                                'duration': null
                            };
                            //create a new object with the desired model template
                            var newObj = Object.assign(template, movie);
                            newObj.film_id = String(newObj.film_id);
                            newObj.release_year = String(newObj.release_year);
                            //add the new objects to the same array as the old objects.
                            result.push(newObj);
                        });
                        //find the amount of old objects in the array.
                        var excessCount = result.length / 2;
                        //delete all the old objects until only the new ones with desired structure and naming convention remains.
                        while (excessCount > 0) {
                            result.shift();
                            excessCount--;
                        }
                        //return the array of new objects with the desired structure.
                        return callback(null, result);
                    }
                })
            }
        })
    },

    getSpecFilmsData: function (title, rental_rate, callback) {
        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                console.log(`Connected!`);
                //console.log(`in the film js page, the value of rental_rate is ${rental_rate}`);
                //create an sql query that joins and selects information about the film from the tables film, fim_category and category
                if (!isNaN(rental_rate)) {
                    var sqlQuery = `SELECT * FROM film WHERE title LIKE '%${title}%' AND rental_rate <= ${rental_rate};`;
                } else {
                    var sqlQuery = `SELECT * FROM film WHERE title LIKE '%${title}%';`;
                }
                console.log(sqlQuery);
                conn.query(sqlQuery, function (err, result) {
                    conn.end();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        console.log(result);
                        return callback(null, result);
                    }
                })
            }
        })
    },

    getFilmCategory: function (callback) {
        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                console.log(`Connected!`);
                var sqlQuery = `SELECT category_id, name FROM category;`;
                conn.query(sqlQuery, function (err, result) {
                    conn.end();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        console.log(result);
                        //returns a list of actor info objects if all goes well.
                        return callback(null, result);
                    }
                })
            }
        })
    },

    getSingleFilmData: function (title, callback) {
        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else {
                console.log(`Connected!`);
                var sqlQuery = `SELECT film.film_id, category.name, film.description, film.rating, film.release_year
                FROM film
                INNER JOIN film_category ON film.film_id=film_category.film_id
                INNER JOIN category ON film_category.category_id=category.category_id
                WHERE film.title = ?`;
                conn.query(sqlQuery, [title], function (err, result) {
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        console.log(result);
                        var sqlQuery2 = `SELECT actor.actor_id, first_name, last_name
                        FROM film
                        INNER JOIN film_actor
                        ON film.film_id = film_actor.film_id
                        INNER JOIN actor
                        ON film_actor.actor_id = actor.actor_id
                        WHERE film.film_id = ?;`;
                        conn.query(sqlQuery2, [result[0].film_id], function (err, result2) {
                            conn.end();
                            if (err) {
                                console.log(err);
                                return callback(err, null);
                            } else {
                                //console.log(result2);
                                result[0].actors = result2;
                                //console.log(`This is the final result ${JSON.stringify(result)}`);
                                return callback(null, result);
                            }
                        });
                    }
                })
            }
        })
    },

};



module.exports = filmDB;

