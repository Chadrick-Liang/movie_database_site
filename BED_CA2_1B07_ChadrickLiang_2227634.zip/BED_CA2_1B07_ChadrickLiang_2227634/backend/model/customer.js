/*Name: Chadrick Liang
Class: DIT/FT/1B/07
Admin No.: P2227634*/
var db = require('./databaseConfig.js');
var config = require('../config.js');
var jwt = require('jsonwebtoken');

var customerDB = {
    addCustomer: function (address1, address2, district, city_id, postal_code, phone, store_id, first_name, last_name, email, callback) {
        var conn = db.getConnection();
        conn.connect(function (err) {
            if (!err) {
                console.log("CONNECTED!");
                //first check if email already exists
                //create a sql query that finds the input email. If email exists, it will return all info from the table customer. If email doesn't exist, it will return nothing.
                var sqlQuery = "SELECT * FROM customer WHERE email = ?";
                conn.query(sqlQuery, [email], function (err, result) {
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else if (!(address1 && district && city_id && postal_code && phone && store_id && first_name && last_name && email)) { //if any of the compulsory fields are missing or left blank, return the missing data error object

                        console.log("missing data");
                        conn.end();
                        return callback(null, { error_msg: "missing data" });
                    } else if (result.length > 0) { //if result has content, it means the email already exists and the existing email error message is returned.
                        console.log("EXISTING EMAIL! " + JSON.stringify(result));
                        conn.end();
                        return callback('EXISTING_EMAIL', { error_msg: "email already exist" });
                    } else { //if the result is nothing, email does not exist and an entry needs to be created in the table address before the entry creation in the table customer.
                        //create an sql query that creates a new address entry with the given information
                        var sqlQuery2 = "INSERT INTO address(address, address2, district, city_id, postal_code, phone) values(?, ?, ?, ?, ?, ?)";
                        conn.query(sqlQuery2, [address1, address2, district, city_id, postal_code, phone], function (err, result2) {
                            if (err) {
                                console.log(err);
                                return callback(err, null);
                            } else {
                                //if no error occurs, address entry is created and the console logs out a success message before the next entry creation.
                                console.log(result2);
                                console.log('Address entry successfully created, moving on to customer entry now.')
                            }
                        });
                        //create an sql query that creates a new customer entry using address_id from the previous entry creation
                        var sqlQuery3 = `INSERT INTO customer(store_id, first_name, last_name, email, address_id) values(?, ?, ?, ?, (SELECT last_insert_id() FROM address LIMIT 1))`;
                        conn.query(sqlQuery3, [store_id, first_name, last_name, email], function (err, result3) {
                            conn.end();
                            if (err) {
                                console.log(err);
                                return callback(err, null);
                            } else { //if no error occurs, return an object containing the customer_id of the newly-created customer.
                                console.log(result3);
                                return callback(null, { customer_id: String(result3.insertId) });
                            }
                        });
                    }
                });
            } else {
                console.log(err);
                return callback(err, null);
            }
        })
    },
};

module.exports = customerDB;