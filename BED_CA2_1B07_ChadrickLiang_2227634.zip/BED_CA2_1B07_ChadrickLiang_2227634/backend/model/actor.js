/*Name: Chadrick Liang
Class: DIT/FT/1B/07
Admin No.: P2227634*/
var db = require('./databaseConfig.js');
var config = require('../config.js');
var jwt = require('jsonwebtoken');

var actorDB = {
    addActor: function (first_name, last_name, callback) {
        var conn = db.getConnection();
        conn.connect(function (err) {
            if (err) {
                console.log(err);
                return callback(err, null);
            } else if (!(first_name && last_name)) { //if first or last name is missing or an empty string, this becomes true
                console.log("missing data");
                conn.end();
                //return error message object
                return callback(null, { error_msg: "missing data" });
            } else {
                console.log("Connected!");
                var sqlQuery = "INSERT INTO actor(first_name, last_name) values(?,?)";
                conn.query(sqlQuery, [first_name, last_name], function (err, result) {
                    conn.end();
                    if (err) {
                        console.log(err);
                        return callback(err, null);
                    } else {
                        console.log(result);
                        //returns an object containing the id of the newly inserted actor
                        return callback(null, { actor_id: String(result.insertId) });
                    }
                })
            }
        })
    },
};

module.exports = actorDB;