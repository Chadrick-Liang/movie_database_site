/*Name: Chadrick Liang
Class: DIT/FT/1B/07
Admin No.: P2227634*/

var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var user = require('../model/user.js');
var film = require('../model/film.js');
var actor = require('../model/actor.js');
var customer = require('../model/customer.js');
var verifyToken = require('../auth/verifyToken.js');
var cors = require('cors');

app.options('*', cors());
app.use(cors());
var urlencodedParser = bodyParser.urlencoded({ extended: false });


app.use(bodyParser.json());
app.use(urlencodedParser);

app.post('/user/login', function (req, res) {
	var username = req.body.username;
	var password = req.body.password;

	user.loginUser(username, password, function (err, token, result) {
		if (!err) {
			res.statusCode = 200;
			res.setHeader('Content-Type', 'application/json');
			delete result[0]['password'];//clear the password in json data, do not send back to client
			console.log(result);
			res.json({ success: true, UserData: JSON.stringify(result), token: token, status: 'You are successfully logged in!' });
			res.send();
		} else {
			res.status(500);
			res.sendStatus(err.statusCode);
		}
	});
});


app.post('/user/logout', function (req, res) {
	console.log("..logging out.");
	res.clearCookie('session-id'); //clears the cookie in the response
	res.setHeader('Content-Type', 'application/json');
	res.json({ success: true, status: 'Log out successful!' });

});


app.get('/film_categories/:category_id/films', function (req, res) {

	//assign the appropriate identifier to the input data in the url params
	var category_id = req.params.category_id;
	film.getFilmsData(category_id, function (err, result) {
		if (!err) { //if no error, send the array of new objects with the desired structure
			res.status(200).send(result);
		} else {
			res.status(500).send({ error_msg: "Internal server error" });
		}
	})
});

app.post('/film_categories/films/search', function (req, res) {

	//assign the appropriate identifier to the input data in the url params
	var title = req.body.title.toUpperCase();
	var rental_rate = req.body.rental_rate;
	//console.log(`CHECKING WHAT THE TITLE IS ${title}`);
	//console.log(`CHECKING WHAT THE RENTAL IS BEFORE CONVERSION ${rental_rate}`);
	rental_rate = parseFloat(rental_rate);
	//console.log(`CHECKING WHAT THE RENTAL IS AFTER CONVERSION ${rental_rate}`);
	film.getSpecFilmsData(title, rental_rate, function (err, result) {
		if (!err) { //if no error, send the array of new objects with the desired structure
			res.status(200).send(result);
		} else {
			res.status(500).send({ error_msg: "Internal server error" });
		}
	})
});

app.get('/film_categories', function (req, res) {

	film.getFilmCategory(function (err, result) {
		if (!err) {
			console.log(result);
			//sends a list of objects
			res.status(200).send(result);
		}
		else {
			console.log(result);
			res.status(500).send({ error_msg: "Internal server error" });
		}
	});
});

app.post('/film_categories/film', function (req, res) {

	//assign the appropriate identifier to the input data in the url params
	var title = req.body.title;
	film.getSingleFilmData(title, function (err, result) {
		if (!err) { //if no error, send the array of new objects with the desired structure
			res.status(200).send(result);
		} else {
			res.status(500).send({ error_msg: "Internal server error" });
		}
	})
});

app.post('/customers', verifyToken, function (req, res) {

	//assign the appropriate identifiers to the input data in the request body
	//console.log(req.body);
	let store_id = req.body.store_id;
	let first_name = req.body.first_name;
	let last_name = req.body.last_name;
	let email = req.body.email;

	let address1 = req.body.address1;
	let address2 = req.body.address2;
	let district = req.body.district;
	let city_id = req.body.city_id;
	let postal_code = req.body.postal_code;
	let phone = req.body.phone;

	customer.addCustomer(address1, address2, district, city_id, postal_code, phone, store_id, first_name, last_name, email, function (err, result) {
		if (!err) {
			//console.log(result);
			if (!(address1 && district && city_id && postal_code && phone && store_id && first_name && last_name && email)) { //if one of the requried fields are empty or missing, return the missing date erro object.
				res.status(400).send(result);
			} else {
				//if database has successfully been updated with a new customer and address entry, return the object containing the newly-created customer's customer_id
				res.status(201).send(result);
			}
		} else {
			if (err == 'EXISTING_EMAIL') { //if the email already exists, return the existing email error object
				res.status(409).send(result);
			} else {
				res.status(500).send({ error_msg: "Internal server error" });
			}
		}
	});

});

app.post('/actors', verifyToken, function (req, res) {

	//assign the appropriate identifiers to the input data in the request body
	let first_name = req.body.first_name;
	let last_name = req.body.last_name;

	actor.addActor(first_name, last_name, function (err, result) {
		if (!err) {
			//console.log(result);
			if (!(first_name && last_name)) { //if first or last name is missing or an empty string, this becomes true and the missing data error object is returned.
				res.status(400).send(result);
			} else { //if actor is added with no issues, result would be the an object containing the actor_id
				res.status(201).send(result);
			}
		} else {
			res.status(500).send({ error_msg: "Internal server error" });
		}
	});

});

module.exports = app;