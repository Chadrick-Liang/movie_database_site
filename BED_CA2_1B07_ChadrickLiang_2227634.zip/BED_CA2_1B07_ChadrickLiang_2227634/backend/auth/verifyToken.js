/*Name: Chadrick Liang
Class: DIT/FT/1B/07
Admin No.: P2227634*/

var jwt = require('jsonwebtoken');

var config = require('../config');

function verifyToken(req, res, next) {
    console.log(req.headers)

    //retrieve content in authorization header
    const authHeader = req.headers['authorization']
    console.log(authHeader)

    //check the content in the authorization headers
    if (!authHeader || !authHeader.includes('Bearer')) {
        return res.status(403).send({ auth: 'false', message: 'Authheader Error' })
    }
    else {
        //retrieve the token value 
        const token = authHeader.replace('Bearer ', '')
        console.log(token)
        //verify the token value
        jwt.verify(token, config.key, function (err, payload) {
            if (err) {
                return res.status(403).send({ auth: 'false', message: 'Authheader Error' })
            }
            else {
                if (payload.role != 'admin') { //checks if user is admin
                    return res.status(401).send({ auth: 'false', message: 'requires administrator rights!' })
                }
                else {
                    return next();
                }

            }
        })
    }


}

module.exports = verifyToken;